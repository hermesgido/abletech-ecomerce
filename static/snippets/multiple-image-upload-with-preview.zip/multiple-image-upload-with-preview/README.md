# Multiple image upload with preview

A Pen created on CodePen.io. Original URL: [https://codepen.io/mrtokachh/pen/LYGvPBj](https://codepen.io/mrtokachh/pen/LYGvPBj).

